import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.ListSelectionModel;
import javax.swing.border.EmptyBorder;
import javax.swing.table.DefaultTableModel;

import net.sf.jasperreports.engine.JRException;
import net.sf.jasperreports.engine.JasperCompileManager;
import net.sf.jasperreports.engine.JasperFillManager;
import net.sf.jasperreports.engine.JasperPrint;
import net.sf.jasperreports.engine.JasperReport;
import net.sf.jasperreports.view.JasperViewer;

import javax.swing.JMenuBar;
import javax.swing.BoxLayout;
import javax.swing.JMenu;
import javax.swing.JMenuItem;
import java.awt.Font;
import java.awt.event.ActionListener;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.awt.event.ActionEvent;
import javax.swing.JButton;
import java.awt.FlowLayout;

public class DashBord extends JFrame {

	private JPanel contentPane;
	public JPanel panel;
	public JTable t;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					DashBord frame = new DashBord();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public DashBord() {
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 656, 412);
		
		JMenuBar menuBar = new JMenuBar();
		setJMenuBar(menuBar);
		
		JMenu mnNewMenu = new JMenu("Fichier");
		mnNewMenu.setFont(new Font("Segoe UI", Font.BOLD, 12));
		menuBar.add(mnNewMenu);
		
		JMenuItem btn_Abonnés = new JMenuItem("Abonnés");
		btn_Abonnés.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				afficherAbonne();
				panel.setVisible(false);
				panel.setVisible(true);
			}
		});
		mnNewMenu.add(btn_Abonnés);
		
		JMenu mnNewMenu_1 = new JMenu("imprimer");
		mnNewMenu_1.setFont(new Font("Segoe UI", Font.BOLD, 12));
		menuBar.add(mnNewMenu_1);
		
		JMenuItem btn_listAbonnés = new JMenuItem("Listes Abonnés");
		btn_listAbonnés.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				//imprimer liste des abonne depuis jasper report
				try {
					Class.forName("com.mysql.jdbc.Driver");
					Connection conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/bibliotheque", "root", "root123");
					String path = "Jasper.jrxml";
					JasperReport jr = JasperCompileManager.compileReport(path);
					JasperPrint jp = JasperFillManager.fillReport(jr,null,conn);
					JasperViewer.viewReport(jp,false);
					conn.close();
				}
				catch(ClassNotFoundException | SQLException | JRException e1) {
					
				}
			}
		});
		mnNewMenu_1.add(btn_listAbonnés);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));

		setContentPane(contentPane);
		contentPane.setLayout(new BoxLayout(contentPane, BoxLayout.X_AXIS));
		
		panel = new JPanel();
		contentPane.add(panel);
		panel.setLayout(null);
		
		JPanel panel_1 = new JPanel();
		panel_1.setBounds(10, 50, 610, 268);
		panel.add(panel_1);
		panel_1.setLayout(new FlowLayout(FlowLayout.CENTER, 5, 5));
		
		JButton btn_nouv = new JButton("Nouveau");
		btn_nouv.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				//ajouter nouveau abonnes
				Abonne a = new Abonne();
				a.btn_ajout.setVisible(true);
				a.setVisible(true);
			}
		});
		btn_nouv.setBounds(90, 11, 89, 23);
		panel.add(btn_nouv);
		
		JButton btnModifier = new JButton("Modifier");
		btnModifier.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				//modifier abonne
				Abonne a = new Abonne();
				a.id_txt.setText(t.getValueAt(t.getSelectedRow(), 0).toString());
				a.nom_txt.setText(t.getValueAt(t.getSelectedRow(), 1).toString());
				a.prenom_txt.setText(t.getValueAt(t.getSelectedRow(), 2).toString());
				a.email_txt.setText(t.getValueAt(t.getSelectedRow(), 3).toString());
				a.adresse_txt.setText(t.getValueAt(t.getSelectedRow(), 4).toString());
				a.btn_modif.setVisible(true);
				a.setVisible(true);
			}
		});
		btnModifier.setBounds(269, 11, 89, 23);
		panel.add(btnModifier);
		
		JButton btnSupprimer = new JButton("Supprimer");
		btnSupprimer.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				//supprimer abonne
				try {
					Class.forName("com.mysql.jdbc.Driver");
					Connection conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/bibliotheque", "root", "root123");
					Statement stmt =  conn.createStatement();
				    stmt.execute("DELETE FROM abonne WHERE ID = "+t.getValueAt(t.getSelectedRow(), 0).toString());
				    panel.setVisible(false);
				    afficherAbonne();
				    panel.setVisible(true);
				} catch (ClassNotFoundException | SQLException e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				}
			}
		});
		btnSupprimer.setBounds(448, 11, 102, 23);
		panel.add(btnSupprimer);
		
		
	}
	public void afficherAbonne()
	{
		try
	    {
	     
	      Class.forName("com.mysql.jdbc.Driver");
	      Connection conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/bibliothgeque", "root", "root123");
	      Statement stmt =  conn.createStatement(ResultSet.TYPE_SCROLL_INSENSITIVE, ResultSet.CONCUR_READ_ONLY);
	      ResultSet res =  stmt.executeQuery("SELECT * FROM abonne");
	      String col[] = { "ID", "Nom", "Prenom" ,"Email","Adresse"};
	      String val[][] = new String[50][5];
	      int i = 0;
	      res.beforeFirst();
	      while(res.next())
	      {
	    	  int ID = res.getInt("ID");
	          String Nom = res.getString("Nom");
	          String Prenom = res.getString("Prenom");
	          String Adresse = res.getString("Email");
	          String Telephone = res.getString("Adresse");
	          val[i][0] = ID + "";
	          val[i][1] = Nom;
	          val[i][2] = Prenom;
	          val[i][3] = Adresse;
	          val[i][4] = Telephone;
	          i++;
	      }
	      DefaultTableModel model = new DefaultTableModel(val, col);
	      t = new JTable(model);
	      t.setColumnSelectionAllowed(true);
	      t.setCellSelectionEnabled(true);
	      t.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);
	      t.setFillsViewportHeight(true);
	      t.setShowGrid(true);
	      t.setShowVerticalLines(true);
	      
	      JScrollPane pane = new JScrollPane(t);
	      panel.add(pane);
	      panel.setVisible(false);
	      panel.setVisible(true);
	      conn.close();
	    }
	    catch(Exception e){ 
	      System.out.println(e);
	    }
	}
}
