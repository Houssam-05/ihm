import java.awt.BorderLayout;
import java.awt.FlowLayout;

import javax.swing.JButton;
import javax.swing.JDialog;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.JLabel;
import java.awt.Font;
import javax.swing.JTextField;
import java.awt.event.ActionListener;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.sql.Statement;
import java.awt.event.ActionEvent;

public class Abonne extends JDialog {

	private final JPanel contentPanel = new JPanel();
	public JTextField id_txt;
	public JTextField nom_txt;
	public JTextField prenom_txt;
	public JTextField email_txt;
	public JTextField adresse_txt;
	public JButton btn_ajout;
	public JButton btn_modif;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		try {
			Abonne ab = new Abonne();
			ab.setDefaultCloseOperation(JDialog.DISPOSE_ON_CLOSE);
			ab.setVisible(true);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	/**
	 * Create the dialog.
	 */
	public Abonne() {
		setDefaultCloseOperation(JDialog.DISPOSE_ON_CLOSE);
		setBounds(100, 100, 299, 300);
		getContentPane().setLayout(new BorderLayout());
		contentPanel.setBorder(new EmptyBorder(5, 5, 5, 5));
		getContentPane().add(contentPanel, BorderLayout.CENTER);
		contentPanel.setLayout(null);
		
		JLabel lblNewLabel = new JLabel("ID");
		lblNewLabel.setFont(new Font("Tahoma", Font.PLAIN, 15));
		lblNewLabel.setBounds(10, 11, 46, 14);
		contentPanel.add(lblNewLabel);
		
		JLabel lblNom = new JLabel("Nom");
		lblNom.setFont(new Font("Tahoma", Font.PLAIN, 15));
		lblNom.setBounds(10, 36, 46, 14);
		contentPanel.add(lblNom);
		
		JLabel lblNewLabel_1_1 = new JLabel("Prenom");
		lblNewLabel_1_1.setFont(new Font("Tahoma", Font.PLAIN, 15));
		lblNewLabel_1_1.setBounds(10, 61, 63, 14);
		contentPanel.add(lblNewLabel_1_1);
		
		JLabel lblNewLabel_1_1_1 = new JLabel("Email");
		lblNewLabel_1_1_1.setFont(new Font("Tahoma", Font.PLAIN, 15));
		lblNewLabel_1_1_1.setBounds(10, 86, 46, 14);
		contentPanel.add(lblNewLabel_1_1_1);
		
		JLabel lblNewLabel_1_1_1_1 = new JLabel("Adresse");
		lblNewLabel_1_1_1_1.setFont(new Font("Tahoma", Font.PLAIN, 15));
		lblNewLabel_1_1_1_1.setBounds(10, 111, 63, 14);
		contentPanel.add(lblNewLabel_1_1_1_1);
		
		id_txt = new JTextField();
		id_txt.setEditable(false);
		id_txt.setFont(new Font("Tahoma", Font.PLAIN, 14));
		id_txt.setBounds(85, 8, 181, 20);
		contentPanel.add(id_txt);
		id_txt.setColumns(15);
		
		nom_txt = new JTextField();
		nom_txt.setFont(new Font("Tahoma", Font.PLAIN, 14));
		nom_txt.setColumns(15);
		nom_txt.setBounds(85, 35, 181, 20);
		contentPanel.add(nom_txt);
		
		prenom_txt = new JTextField();
		prenom_txt.setFont(new Font("Tahoma", Font.PLAIN, 14));
		prenom_txt.setColumns(15);
		prenom_txt.setBounds(85, 60, 181, 20);
		contentPanel.add(prenom_txt);
		
		email_txt = new JTextField();
		email_txt.setFont(new Font("Tahoma", Font.PLAIN, 14));
		email_txt.setColumns(15);
		email_txt.setBounds(85, 85, 181, 20);
		contentPanel.add(email_txt);
		
		adresse_txt = new JTextField();
		adresse_txt.setFont(new Font("Tahoma", Font.PLAIN, 14));
		adresse_txt.setColumns(15);
		adresse_txt.setBounds(85, 108, 181, 20);
		contentPanel.add(adresse_txt);
		{
			JPanel buttonPane = new JPanel();
			buttonPane.setLayout(new FlowLayout(FlowLayout.RIGHT));
			getContentPane().add(buttonPane, BorderLayout.SOUTH);
			{
				 btn_ajout = new JButton("Ajouter");
				 btn_ajout.addActionListener(new ActionListener() {
				 	public void actionPerformed(ActionEvent e) {
				 		//ajouter abonne
				 		try {
							Class.forName("com.mysql.jdbc.Driver");
							Connection conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/bibliotheque", "root", "root123");
							Statement stmt =  conn.createStatement();
						    stmt.execute("INSERT INTO `bibliotheque`.`abonne` (`Nom`, `Prenom`, `Email`,`Adresse`)"
						    + " VALUES ('"+nom_txt.getText().toString()+"', '"+prenom_txt.getText().toString()+"', '"
						    		+email_txt.getText().toString()+"','"+adresse_txt.getText().toString()+"')");
						    dispose();
						    conn.close();
						} catch (ClassNotFoundException | SQLException e1) {
							// TODO Auto-generated catch block
							e1.printStackTrace();
						}	
				 	}
				 });
				//okButton.setActionCommand("OK");
				buttonPane.add(btn_ajout);
				btn_ajout.setVisible(false);
				getRootPane().setDefaultButton(btn_ajout);
			}
			{
				btn_modif = new JButton("Modifier");
				btn_modif.addActionListener(new ActionListener() {
					public void actionPerformed(ActionEvent e) {
						//modifier abonne
						try {
							Class.forName("com.mysql.jdbc.Driver");
							Connection conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/bibliotheque", "root", "root123");
							Statement stmt =  conn.createStatement();
						    stmt.executeUpdate("UPDATE `bibliotheque`.`abonne` SET `Nom` = '"+nom_txt.getText().toString()+
						    		"', `Prenom` = '"+prenom_txt.getText().toString()+"', `Email` = '"+email_txt.getText().toString()
						    		+"'Adresse' = '"+adresse_txt.getText().toString()+"' WHERE (`ID` = '"+id_txt.getText().toString()+"');");
						    dispose();//fermer dialog box
						    conn.close();
						} catch (ClassNotFoundException | SQLException e1) {
							// TODO Auto-generated catch block
							e1.printStackTrace();
						}
					}
				});
				//cancelButton.setActionCommand("Cancel");
				buttonPane.add(btn_modif);
				btn_modif.setVisible(false);
			}
		}
	}
}
